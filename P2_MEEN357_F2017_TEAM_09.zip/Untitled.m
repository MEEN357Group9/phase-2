run car_2014.m

x = get_cg(FSAE_Race_Car)

j = get_Jy(FSAE_Race_Car)
